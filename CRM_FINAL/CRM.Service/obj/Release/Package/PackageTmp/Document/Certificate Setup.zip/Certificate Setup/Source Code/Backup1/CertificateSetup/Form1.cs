using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Resources;


namespace CertificateSetup
{
    public partial class Form1 : Form
    {
        private string fullLocalMachineName;
        
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            getTheFullClientName();
            this.txtCertificateName.Text = fullLocalMachineName;
        }

        private void getTheFullClientName()
        {
            string simpleHostName = Dns.GetHostName();
            System.Net.IPHostEntry iphostname = Dns.GetHostEntry(simpleHostName);
            fullLocalMachineName = iphostname.HostName;
        }

        private void btnCreateCertificate_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process x = new System.Diagnostics.Process();
            x.StartInfo.FileName = @"SelfSSL Executable\selfssl.exe";
            x.StartInfo.Arguments = "/T /N:CN=" + fullLocalMachineName + " /V:365 /Q";
            x.StartInfo.RedirectStandardOutput = true;
            x.StartInfo.UseShellExecute = false;
            x.StartInfo.CreateNoWindow = true;
            x.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
            x.Start();
            MessageBox.Show("Done...Please check IIS (as shown in workshop) to confirm");
            Application.Exit();
        }
    }
}